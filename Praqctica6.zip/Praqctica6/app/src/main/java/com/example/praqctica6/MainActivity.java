package com.example.praqctica6;

import android.content.pm.ActivityInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private TextView aceX, aceY, aceZ, maxX, maxY, maxZ, minX, minY, minZ;

    private float actualX = 0, actualY = 0, actualZ = 0;
    private float maxXValue = Float.MIN_VALUE, maxYValue = Float.MIN_VALUE, maxZValue = Float.MIN_VALUE;
    private float minXValue = Float.MAX_VALUE, minYValue = Float.MAX_VALUE, minZValue = Float.MAX_VALUE;

    private SensorManager sensorManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        // Inicializar TextViews
        aceX = findViewById(R.id.aceX);
        aceY = findViewById(R.id.aceY);
        aceZ = findViewById(R.id.aceZ);
        maxX = findViewById(R.id.maxX);
        maxY = findViewById(R.id.maxY);
        maxZ = findViewById(R.id.maxZ);
        minX = findViewById(R.id.minX);
        minY = findViewById(R.id.minY);
        minZ = findViewById(R.id.minZ);

        // Inicializar SensorManager
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
    }

    @Override
    public void onResume() {
        super.onResume();
        List<Sensor> sensores = sensorManager.getSensorList(Sensor.TYPE_ACCELEROMETER);
        if (sensores.size() > 0) {
            sensorManager.registerListener(this, sensores.get(0), SensorManager.SENSOR_DELAY_GAME);
        }
    }

    @Override
    protected void onStop() {
        sensorManager.unregisterListener(this);
        super.onStop();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        synchronized (this) {
            actualX = event.values[0];
            actualY = event.values[1];
            actualZ = event.values[2];

            // Actualizar valores máximos
            if (actualX > maxXValue) maxXValue = actualX;
            if (actualY > maxYValue) maxYValue = actualY;
            if (actualZ > maxZValue) maxZValue = actualZ;

            // Actualizar valores mínimos
            if (actualX < minXValue) minXValue = actualX;
            if (actualY < minYValue) minYValue = actualY;
            if (actualZ < minZValue) minZValue = actualZ;

            // Mostrar valores actuales
            aceX.setText("Valor en X: " + String.format("%.2f", actualX));
            aceY.setText("Valor en Y: " + String.format("%.2f", actualY));
            aceZ.setText("Valor en Z: " + String.format("%.2f", actualZ));

            // Mostrar máximos
            maxX.setText(String.format("%.2f", maxXValue));
            maxY.setText(String.format("%.2f", maxYValue));
            maxZ.setText(String.format("%.2f", maxZValue));

            // Mostrar mínimos
            minX.setText(String.format("%.2f", minXValue));
            minY.setText(String.format("%.2f", minYValue));
            minZ.setText(String.format("%.2f", minZValue));
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
