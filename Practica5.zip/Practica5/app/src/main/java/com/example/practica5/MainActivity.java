package com.example.practica5;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Vista vista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vista = new Vista(this);

        FrameLayout lienzo = findViewById(R.id.lienzo);
        lienzo.addView(vista);

        Button btnRojo = findViewById(R.id.btnRojo);
        Button btnVerde = findViewById(R.id.btnVerde);
        Button btnAzul = findViewById(R.id.btnAzul);

        btnRojo.setOnClickListener(v -> vista.setColor(Color.RED));
        btnVerde.setOnClickListener(v -> vista.setColor(Color.GREEN));
        btnAzul.setOnClickListener(v -> vista.setColor(Color.BLUE));
    }

    class Vista extends View {

        float x, y;
        String accion = "";
        int colorActual = Color.BLUE;

        ArrayList<Trazo> trazos = new ArrayList<>();
        Path pathActual;

        public Vista(Context context) {
            super(context);
        }

        public void setColor(int color) {
            colorActual = color;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            for (Trazo t : trazos) {
                canvas.drawPath(t.path, t.paint);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            x = event.getX();
            y = event.getY();

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    pathActual = new Path();
                    pathActual.moveTo(x, y);

                    Paint paint = new Paint();
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(5);
                    paint.setColor(colorActual);
                    paint.setAntiAlias(true);

                    trazos.add(new Trazo(pathActual, paint));
                    break;

                case MotionEvent.ACTION_MOVE:
                    pathActual.lineTo(x, y);
                    break;
            }

            invalidate();
            return true;
        }
    }

    class Trazo {
        Path path;
        Paint paint;

        public Trazo(Path path, Paint paint) {
            this.path = path;
            this.paint = paint;
        }
    }
}
