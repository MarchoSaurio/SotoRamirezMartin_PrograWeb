package com.example.listadeelementos;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private TextView textAtributo;
    private ListView listView;
    private Button btnSalir;

    private String signos[] = {"Aries", "Tauro", "Géminis", "Cáncer", "Leo", "Virgo", "Libra", "Escorpio", "Sagitario", "Capricornio", "Acuario", "Piscis"};
    private String periodos[] = {"21-Mar, 19-Abr", "20-Abr, 20-May", "21-May, 20-Jun", "21-Jun, 22-Jul", "23-Jul, 22-Ago", "23-Ago, 22-Sep", "23-Sep, 22-Oct", "23-Oct, 21-Nov", "22-Nov, 21-Dic", "22-Dic, 19-Ene", "20-Ene, 18-Feb", "19-Feb, 20-Mar"};
    private String atributos[] = {
            "Valientes y decididos.",
            "Pacientes y confiables.",
            "Curiosos y adaptables.",
            "Emocionales y protectores.",
            "Apasionados y líderes.",
            "Analíticos y prácticos.",
            "Diplomáticos y encantadores.",
            "Intensos y misteriosos.",
            "Aventureros y optimistas.",
            "Responsables y disciplinados.",
            "Originales e independientes.",
            "Empáticos y artísticos."
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        textAtributo = findViewById(R.id.textAtributo);
        listView = findViewById(R.id.listView);
        btnSalir = findViewById(R.id.btnSalir);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.list_item_signo, R.id.textItem, signos);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
                        textView.setText("Periodo: " + periodos[i]);
                        textAtributo.setText("Atributo: " + atributos[i]);
                    }
                }
        );

        btnSalir.setOnClickListener(v -> finish()); // Cierra la app
    }
}
